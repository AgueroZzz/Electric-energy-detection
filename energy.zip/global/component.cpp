#include "component.h"

component::component(QObject *parent)
    : QObject{parent}
{}
