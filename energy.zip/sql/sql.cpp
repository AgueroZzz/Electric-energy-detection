#include "sql.h"

sql::sql(QObject *parent)
    : QObject{parent}
{}
